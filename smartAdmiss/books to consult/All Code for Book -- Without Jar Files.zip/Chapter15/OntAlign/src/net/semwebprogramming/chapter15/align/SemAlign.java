package net.semwebprogramming.chapter15.align;

public class SemAlign {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Starting Alignment");

	}

}
