package net.semwebprogramming.chapter8.JenaExploration;

import java.util.Map;

import com.hp.hpl.jena.shared.PrefixMapping;

public class CustomPrefixMapping implements PrefixMapping {

    @Override
    public String expandPrefix(String arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Map getNsPrefixMap() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getNsPrefixURI(String arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getNsURIPrefix(String arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PrefixMapping lock() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String qnameFor(String arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PrefixMapping removeNsPrefix(String arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean samePrefixMappingAs(PrefixMapping arg0) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public PrefixMapping setNsPrefix(String arg0, String arg1) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PrefixMapping setNsPrefixes(PrefixMapping arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PrefixMapping setNsPrefixes(Map arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String shortForm(String arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PrefixMapping withDefaultMappings(PrefixMapping arg0) {
        // TODO Auto-generated method stub
        return null;
    }

}
