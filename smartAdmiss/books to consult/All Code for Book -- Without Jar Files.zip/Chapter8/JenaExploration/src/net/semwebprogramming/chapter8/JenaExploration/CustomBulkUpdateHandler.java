package net.semwebprogramming.chapter8.JenaExploration;

import java.util.Iterator;
import java.util.List;

import com.hp.hpl.jena.graph.BulkUpdateHandler;
import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Triple;

public class CustomBulkUpdateHandler implements BulkUpdateHandler {

    @Override
    public void add(Triple[] arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void add(List arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void add(Iterator arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void add(Graph arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void add(Graph arg0, boolean arg1) {
        // TODO Auto-generated method stub

    }

    @Override
    public void delete(Triple[] arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void delete(List arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void delete(Iterator arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void delete(Graph arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void delete(Graph arg0, boolean arg1) {
        // TODO Auto-generated method stub

    }

    @Override
    public void remove(Node arg0, Node arg1, Node arg2) {
        // TODO Auto-generated method stub

    }

    @Override
    public void removeAll() {
        // TODO Auto-generated method stub

    }

}
