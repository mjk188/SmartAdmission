package net.semwebprogramming.chapter8.JenaExploration;

import com.hp.hpl.jena.graph.GraphStatisticsHandler;
import com.hp.hpl.jena.graph.Node;

public class CustomGraphStatisticsHandler implements GraphStatisticsHandler {

    @Override
    public long getStatistic(Node arg0, Node arg1, Node arg2) {
        // TODO Auto-generated method stub
        return 0;
    }

}
